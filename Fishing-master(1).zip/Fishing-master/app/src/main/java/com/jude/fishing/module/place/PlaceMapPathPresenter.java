package com.jude.fishing.module.place;

import com.jude.beam.bijection.Presenter;

/**
 * Created by zhuchenxi on 15/10/16.
 */
public class PlaceMapPathPresenter extends Presenter<PlaceMapPathActivity> {
}
