package com.jude.fishing.module.social;

import com.jude.beam.bijection.Presenter;

/**
 * Created by Mr.Jude on 2015/9/11.
 */
public class MessagePresenter extends Presenter<MessageFragment> {
}
