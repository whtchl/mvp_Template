package com.jude.fishing.module.social;

import com.jude.beam.bijection.Presenter;

/**
 * Created by zhuchenxi on 15/7/21.
 */
public class ChatPresenter extends Presenter<ChatActivity> {
}
