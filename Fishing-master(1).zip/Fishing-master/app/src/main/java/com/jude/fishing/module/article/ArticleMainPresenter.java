package com.jude.fishing.module.article;

import com.jude.beam.bijection.Presenter;

/**
 * Created by zhuchenxi on 15/12/24.
 */
public class ArticleMainPresenter extends Presenter<ArticleMainFragment> {
}
