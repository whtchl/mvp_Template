package com.jude.fishing.module.setting;

import com.jude.beam.bijection.Presenter;

/**
 * Created by Mr.Jude on 2015/12/13.
 */
public class DevelopPresenter extends Presenter<DevelopActivity> {
}
