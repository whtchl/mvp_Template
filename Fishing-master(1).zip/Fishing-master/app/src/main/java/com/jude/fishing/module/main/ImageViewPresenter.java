package com.jude.fishing.module.main;

import com.jude.beam.bijection.Presenter;

/**
 * Created by Mr.Jude on 2015/10/24.
 */
public class ImageViewPresenter extends Presenter<ImageViewActivity> {
}
