package com.jude.fishing.config;

/**
 * Created by Mr.Jude on 2015/9/11.
 */
public enum Dir {
    Image,Object
}
