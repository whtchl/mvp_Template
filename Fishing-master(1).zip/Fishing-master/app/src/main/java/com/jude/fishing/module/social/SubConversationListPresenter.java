package com.jude.fishing.module.social;

import com.jude.beam.bijection.Presenter;

/**
 * Created by heqiang on 2015/12/3.
 */
public class SubConversationListPresenter extends Presenter<SubConversationListActivtiy>{
}
