package com.jude.fishing.module.place;

import com.jude.beam.bijection.Presenter;

/**
 * Created by Mr.Jude on 2015/10/10.
 */
public class PlaceLocationSelectPresenter extends Presenter<PlaceLocationSelectActivity> {
}
